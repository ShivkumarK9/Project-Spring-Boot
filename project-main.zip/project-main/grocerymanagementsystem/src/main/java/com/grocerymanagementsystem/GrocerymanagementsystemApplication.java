package com.grocerymanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrocerymanagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrocerymanagementsystemApplication.class, args);
	}

}

package com.grocerymanagementsystem.service;

import com.grocerymanagementsystem.entity.User;

//importing packages

/*
@ Program: creating service class
code by : Swapnil
Date : 16 December 2022
*/

public interface UserService 
{
	String createUser(User user);
	 

}

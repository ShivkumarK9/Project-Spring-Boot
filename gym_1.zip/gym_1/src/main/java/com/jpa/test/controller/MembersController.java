package com.jpa.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpa.test.entity.Members;
import com.jpa.test.exception.ResourceNotFoundException;
import com.jpa.test.repository.MembersRepository;

@RestController
@RequestMapping("/api/members")
public class MembersController {

	
	@Autowired
	public MembersRepository membersRepository;
	
	//get all members
	@GetMapping
	public List<Members>getAllMembers(){
		return this.membersRepository.findAll();
	}
		//get members by id
	@GetMapping("/{id}")
		public Members getMembersById(@PathVariable (value = "id") long membersId) {
			return this.membersRepository.findById(membersId)
					.orElseThrow(()->new ResourceNotFoundException("user not found with id:" + membersId));
	}
	//create Members
	@PostMapping
	public Members createMembers(@RequestBody Members members) {
		
		return this.membersRepository.save(members);
	}
			//update Members
	@PutMapping("/{id}")
	public Members updateMembers(@RequestBody Members members,@PathVariable("id") long membersId) {
		Members existingMembers =  this.membersRepository.findById(membersId)
				.orElseThrow(()->new ResourceNotFoundException("user not found with id:" + membersId));
		existingMembers.setFirstName(members.getFirstName());
		existingMembers.setLastName(members.getLastName());
		existingMembers.setEmail(members.getEmail());
		existingMembers.setMembership(members.getMembership());
		return this.membersRepository.save(existingMembers);
	}
	//delete Members by id
	@DeleteMapping("/{id}")
	public ResponseEntity<Members> deleteMembers(@PathVariable ("id")long membersId){
		Members existingMembers =  this.membersRepository.findById(membersId)
				.orElseThrow(()->new ResourceNotFoundException("user not found with id:" + membersId));
		this.membersRepository.delete(existingMembers);
		return ResponseEntity.ok().build();
		
		
	}

		}
		
	
	


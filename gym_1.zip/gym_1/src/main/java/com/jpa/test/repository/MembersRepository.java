package com.jpa.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpa.test.entity.Members;


public interface MembersRepository extends JpaRepository <Members,Long>{

}
